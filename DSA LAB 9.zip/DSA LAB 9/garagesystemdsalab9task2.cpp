#include <iostream>
#include <string>
using namespace std;

#define MAX 10  

class GarageSystem {
private:
    int road[MAX];    
    int front, rear;

    int garage[MAX];  
    int top;

public:
    GarageSystem() {
        front=rear= -1;
        top=-1;
    }

    bool roadIsFull() {
        return (rear == MAX - 1);
    }

    bool roadIsEmpty() {
        return (front == -1 || front > rear);
    }

    bool garageIsFull() {
        return (top == MAX - 1);
    }

    bool garageIsEmpty() {
        return (top==-1);
    }

    void On_road(int truck_id) {
        if (roadIsFull()) {
            cout<<"Road is full. Cannot add more trucks.\n";
            return;
        }

        if (front==-1)
            front=0;
        rear++;
        road[rear]=truck_id;
        cout<<"Truck "<<truck_id<<" added to road.\n";
    }

    void Enter_garage(int truck_id) {
        if (roadIsEmpty()) {
            cout<<"No trucks on the road.\n";
            return;
        }

        if (road[front] != truck_id) {
            cout<<"Truck "<<truck_id << "is not at the front of the road. Cannot enter garage.\n";
            return;
        }

        if (garageIsFull()) {
            cout<<"Garage is full!\n";
            return;
        }

        top++;
        garage[top]=truck_id;
        cout<<"Truck "<<truck_id<<" entered the garage.\n";
        front++;
    }

    void Exit_garage(int truck_id) {
        if (garageIsEmpty()) {
            cout<<"Garage is empty.\n";
            return;
        }

        if (garage[top] == truck_id) {
            cout<<"Truck "<<truck_id << "exited the garage.\n";
            top--;
        } else {
            cout<<"Truck is not near garage door.\n";
        }
    }

    void Show_trucks(string location) {
        if (location=="road") {
            if (roadIsEmpty()) {
                cout << "Road is empty.\n";
                return;
            }

            cout<<"Trucks on road (front ? rear): ";
            for (int i = front; i <= rear; i++) {
                cout<< road[i] << " ";
            }
            cout<<endl;
        } 
        else if (location=="garage") {
            if (garageIsEmpty()) {
                cout<<"Garage is empty.\n";
                return;
            }

            cout<<"Trucks in garage (top ? bottom): ";
            for (int i = top; i >= 0; i--) {
                cout<<garage[i]<< " ";
            }
            cout<<endl;
        } 
        else {
            cout<<"Invalid location! Use 'road' or 'garage'.\n";
        }
    }
};

int main() {
    GarageSystem system;
    int choice, id;
    string location;

    do {
        
        cout<<"1. On_road \n";
        cout<<"2. Enter_garage \n";
        cout<<"3. Exit_garage \n";
        cout<<"4. Show_trucks \n";
        cout<<"5. Exit\n";
        cout<<"Enter your choice: ";
        cin>>choice;

        switch (choice) {
        case 1:
            cout<<"Enter Truck ID to add on road: ";
            cin>>id;
            system.On_road(id);
            break;

        case 2:
            cout<<"Enter Truck ID to enter garage: ";
            cin>>id;
            system.Enter_garage(id);
            break;

        case 3:
            cout<<"Enter Truck ID to exit garage: ";
            cin>>id;
            system.Exit_garage(id);
            break;

        case 4:
            cout<<"Enter location (garage or road): ";
            cin>>location;
            system.Show_trucks(location);
            break;

        case 5:
            cout<<"Exiting program...\n";
            break;

        default:
            cout<<"Invalid choice. Try again.\n";
        }
    } while (choice!=5);

    return 0;
}

