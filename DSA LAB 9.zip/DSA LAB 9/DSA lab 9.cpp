#include <iostream>
#include <string>
using namespace std;

struct Applicant {
    int applicant_id;
    float height;
    float weight;
    float eyesight;
    string status;
};

struct Node {
    Applicant data;
    Node* next;
    Node* prev;
};

class ApplicantQueue {
private:
    Node* front;
    Node* rear;

public:
    ApplicantQueue() {
        front = rear = NULL;
    }

    bool isEmpty() {
        return front == NULL;
    }

    void enqueue(Applicant a) {
        Node* newNode = new Node;
        newNode->data = a;
        newNode->next = NULL;
        newNode->prev = NULL;

        if (rear == NULL) {
            front = rear = newNode;
        } else {
            rear->next = newNode;
            newNode->prev = rear;
            rear = newNode;
        }
        cout << "Applicant " << a.applicant_id << " added successfully.\n";
    }

    void dequeue() {
        if (front == NULL) {
            cout << "No applicants in queue.\n";
            return;
        }
        Node* temp = front;
        cout << "Applicant " << temp->data.applicant_id << " has given the test and left the line.\n";
        front = front->next;
        if (front != NULL)
            front->prev = NULL;
        else
            rear = NULL;
        delete temp;
    }

    void removeAtPosition(int pos) {
        if (front == NULL) {
            cout << "Queue is empty.\n";
            return;
        }
        Node* temp = front;
        int count = 1;
        while (temp != NULL && count < pos) {
            temp = temp->next;
            count++;
        }
        if (temp == NULL) {
            cout << "Invalid position.\n";
            return;
        }
        cout << "Applicant " << temp->data.applicant_id << " left due to urgency.\n";
        if (temp->prev != NULL)
            temp->prev->next = temp->next;
        else
            front = temp->next;
        if (temp->next != NULL)
            temp->next->prev = temp->prev;
        else
            rear = temp->prev;
        delete temp;
    }

    void display() {
        if (front == NULL) {
            cout << "No applicants in the line.\n";
            return;
        }
        cout << "\nCurrent Applicants in Queue:\n";
        Node* temp = front;
        while (temp != NULL) {
            cout << "ID: " << temp->data.applicant_id
                 << " | Height: " << temp->data.height
                 << " | Weight: " << temp->data.weight
                 << " | Eyesight: " << temp->data.eyesight
                 << " | Status: " << temp->data.status << endl;
            temp = temp->next;
        }
    }

    ~ApplicantQueue() {
        while (front != NULL)
            dequeue();
    }
};

int main() {
    ApplicantQueue q;
    int choice;

    do {
        cout << "\n*** Applicants Queue Using Doubly Linked List ***\n";
        cout << "1. Add Applicant (Enqueue)\n";
        cout << "2. Applicant Gives Test (Dequeue)\n";
        cout << "3. Urgent Leave (Remove 2nd Position)\n";
        cout << "4. Display All Applicants\n";
        cout << "5. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            Applicant a;
            cout << "Enter Applicant ID: ";
            cin >> a.applicant_id;
            cout << "Enter Height: ";
            cin >> a.height;
            cout << "Enter Weight: ";
            cin >> a.weight;
            cout << "Enter Eyesight number: ";
            cin >> a.eyesight;
            cout << "Enter Status of test (Pending/Done): ";
            cin >> a.status;
            q.enqueue(a);
            break;
        }
        case 2:
            q.dequeue();
            break;

        case 3:
            q.removeAtPosition(2);
            break;

        case 4:
            q.display();
            break;

        case 5:
            cout << "Exiting program...\n";
            break;

        default:
            cout << "Invalid choice. Try again.\n";
        }

    } while (choice != 5);

    return 0;
}


